# n8n Context-Aware Assistant App Requirements

## Overview
Based on the video analysis, this document outlines the requirements for developing a lightweight context-aware assistant app for n8n that helps with JSON formatting, workflow error correction, prompt writing, and other n8n-related tasks.

## Core Features

### 1. Context-Aware Chat Interface
- Dark mode UI with green accent colors for visibility
- Floating chat window that can be minimized/maximized
- Ability to ask questions about current n8n workflow
- Persistent across different n8n screens and workflows
- Input field with send button
- Chat history display with clear formatting

### 2. Interchangeable AI Agents
- Support for multiple LLM providers:
  - Anthropic (Claude Sonnet 4)
  - OpenAI (GPT-4.1)
  - Other providers can be added
- UI for switching between different AI models
- API key management for each provider
- Configuration saving functionality

### 3. JSON Formatting and Correction
- Ability to generate JSON based on natural language descriptions
- JSON validation and error correction
- Display of formatted JSON with syntax highlighting
- Ability to fix malformed JSON automatically

### 4. Code Generation
- JavaScript code generation for n8n workflows
- Code explanation capabilities
- Syntax highlighting for generated code
- Support for different programming languages

### 5. Workflow Error Correction
- Ability to analyze workflow errors
- Suggestions for fixing common n8n workflow issues
- Step-by-step guidance for resolving errors

### 6. Prompt Writing Assistance
- Templates for effective prompts
- Ability to generate prompts based on user needs
- Optimization suggestions for existing prompts
- Support for different prompt styles and formats

### 7. n8n Integration
- Seamless integration with n8n workflow editor
- Access to workflow context and data
- Ability to trigger from within n8n interface
- Support for n8n node configuration assistance

### 8. Knowledge Base
- Built-in knowledge of n8n documentation
- Access to common workflow patterns
- Troubleshooting guides
- Fallback to web search when internal knowledge is insufficient

## Technical Requirements

### UI/UX
- Dark mode interface with green accent colors
- Responsive design that works within n8n's interface
- Minimalist, clean aesthetic
- Keyboard shortcuts for common actions
- Collapsible/expandable interface elements

### Backend
- API integration with multiple LLM providers
- Secure API key storage
- Efficient context management
- Local knowledge base for n8n documentation
- Web search capability as fallback

### Performance
- Fast response times
- Efficient resource usage
- Minimal impact on n8n performance
- Graceful error handling

### Security
- Secure handling of API keys
- No data sharing outside of user's environment
- Privacy-focused design

## Integration Points
- n8n workflow editor
- n8n node configuration panels
- n8n execution results view
- n8n error messages

## User Experience Flow
1. User opens n8n and sees the assistant icon
2. User clicks to expand the assistant chat interface
3. User can type questions or requests related to their current workflow
4. Assistant provides contextually relevant responses
5. User can switch between different AI providers as needed
6. Assistant helps with JSON formatting, code generation, error correction, and prompt writing
7. User can minimize the assistant when not needed

## Non-Functional Requirements
- For personal use only (audience of one)
- Must contain knowledge from n8n documentation
- Should prioritize internal knowledge before web search
- Must have proper error handling and reporting
- Dark mode UI is required
- Must support interchangeable AI agents
