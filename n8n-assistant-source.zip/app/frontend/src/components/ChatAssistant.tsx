import React, { useState, useEffect, useRef } from 'react';
import { MessageCircle, Send, X, Settings, Loader, Moon, Sun } from 'lucide-react';
import '../styles/globals.css';
import { useLLM, llmProviders } from '../contexts/LLMContext';
import { useAssistant } from '../hooks/useAssistant';
import { useTheme } from '../contexts/ThemeContext';

// Define message type
interface Message {
  id: string;
  content: string;
  sender: 'user' | 'bot';
  timestamp: Date;
  isLoading?: boolean;
}

const ChatAssistant: React.FC = () => {
  const { selectedProvider, setSelectedProvider, apiKeys, setApiKey, getProvider } = useLLM();
  const { sendMessage, isLoading, error } = useAssistant();
  const { theme, toggleTheme } = useTheme();
  const [messages, setMessages] = useState<Message[]>([]);
  const [inputValue, setInputValue] = useState('');
  const [isOpen, setIsOpen] = useState(true);
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  // Add initial welcome message
  useEffect(() => {
    setMessages([
      {
        id: '1',
        content: 'How can I help with n8n today?',
        sender: 'bot',
        timestamp: new Date()
      }
    ]);
  }, []);

  // Scroll to bottom when messages change
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  const handleSendMessage = async () => {
    if (!inputValue.trim() || isLoading) return;

    // Add user message
    const userMessage: Message = {
      id: Date.now().toString(),
      content: inputValue,
      sender: 'user',
      timestamp: new Date()
    };

    // Add loading message
    const loadingMessageId = (Date.now() + 1).toString();
    const loadingMessage: Message = {
      id: loadingMessageId,
      content: 'Thinking...',
      sender: 'bot',
      timestamp: new Date(),
      isLoading: true
    };

    setMessages(prev => [...prev, userMessage, loadingMessage]);
    setInputValue('');

    try {
      // Get response from assistant
      const response = await sendMessage(inputValue);
      
      // Replace loading message with actual response
      setMessages(prev => 
        prev.map(msg => 
          msg.id === loadingMessageId 
            ? {
                id: loadingMessageId,
                content: response,
                sender: 'bot',
                timestamp: new Date(),
                isLoading: false
              }
            : msg
        )
      );
    } catch (err) {
      // Handle error
      setMessages(prev => 
        prev.map(msg => 
          msg.id === loadingMessageId 
            ? {
                id: loadingMessageId,
                content: `Error: ${err instanceof Error ? err.message : 'Unknown error occurred'}`,
                sender: 'bot',
                timestamp: new Date(),
                isLoading: false
              }
            : msg
        )
      );
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent) => {
    if (e.key === 'Enter' && !e.shiftKey) {
      e.preventDefault();
      handleSendMessage();
    }
  };

  const handleProviderChange = (providerId: string) => {
    setSelectedProvider(providerId);
  };

  const handleApiKeyChange = (providerId: string, value: string) => {
    setApiKey(providerId, value);
  };

  const toggleChat = () => {
    setIsOpen(prev => !prev);
    setIsSettingsOpen(false);
  };

  const toggleSettings = () => {
    setIsSettingsOpen(prev => !prev);
  };

  return (
    <div className="n8n-assistant">
      {/* Chat toggle button */}
      <button 
        className="fixed bottom-4 right-4 z-50 rounded-full bg-primary p-3 text-primary-foreground shadow-lg"
        onClick={toggleChat}
      >
        {isOpen ? <X size={24} /> : <MessageCircle size={24} />}
      </button>

      {/* Chat window */}
      {isOpen && (
        <div className="n8n-assistant-chat">
          {/* Header */}
          <div className="n8n-assistant-header">
            <div className="flex items-center gap-2">
              <MessageCircle size={20} />
              <span>Chat with n8n boy</span>
            </div>
            <div className="flex items-center gap-2">
              <button onClick={toggleTheme} className="p-1 rounded-full hover:bg-primary-foreground/10">
                {theme === 'dark' ? <Sun size={18} /> : <Moon size={18} />}
              </button>
              <button onClick={toggleSettings}>
                <Settings size={20} />
              </button>
            </div>
          </div>

          {/* Settings panel */}
          {isSettingsOpen && (
            <div className="n8n-assistant-settings">
              <div className="n8n-assistant-settings-section">
                <h3 className="n8n-assistant-settings-title">LLM Provider</h3>
                <div className="space-y-2">
                  {llmProviders.map(provider => (
                    <div key={provider.id} className="flex items-center gap-2">
                      <input
                        type="radio"
                        id={provider.id}
                        name="provider"
                        checked={selectedProvider === provider.id}
                        onChange={() => handleProviderChange(provider.id)}
                        className="h-4 w-4 text-primary"
                      />
                      <label htmlFor={provider.id}>{provider.name}</label>
                    </div>
                  ))}
                </div>
              </div>

              <div className="n8n-assistant-settings-section">
                <h3 className="n8n-assistant-settings-title">API Keys</h3>
                <div className="space-y-3">
                  {llmProviders.map(provider => (
                    <div key={`key-${provider.id}`} className="space-y-1">
                      <label htmlFor={`key-${provider.id}`} className="text-sm">
                        {provider.name} API Key
                      </label>
                      <input
                        type="password"
                        id={`key-${provider.id}`}
                        value={apiKeys[provider.id] || ''}
                        onChange={(e) => handleApiKeyChange(provider.id, e.target.value)}
                        className="n8n-assistant-api-key-input"
                        placeholder={`Enter your ${provider.name} API key`}
                      />
                    </div>
                  ))}
                </div>
              </div>

              <div className="n8n-assistant-settings-section">
                <h3 className="n8n-assistant-settings-title">Theme</h3>
                <div className="flex items-center gap-2">
                  <button 
                    onClick={() => toggleTheme()}
                    className={`px-3 py-2 rounded-md ${theme === 'dark' ? 'bg-primary text-primary-foreground' : 'bg-secondary'}`}
                  >
                    <div className="flex items-center gap-2">
                      <Moon size={16} />
                      <span>Dark</span>
                    </div>
                  </button>
                  <button 
                    onClick={() => toggleTheme()}
                    className={`px-3 py-2 rounded-md ${theme === 'light' ? 'bg-primary text-primary-foreground' : 'bg-secondary'}`}
                  >
                    <div className="flex items-center gap-2">
                      <Sun size={16} />
                      <span>Light</span>
                    </div>
                  </button>
                </div>
              </div>

              <button 
                className="w-full rounded-md bg-primary py-2 text-primary-foreground"
                onClick={() => setIsSettingsOpen(false)}
              >
                Save Configuration
              </button>
            </div>
          )}

          {/* Messages */}
          {!isSettingsOpen && (
            <>
              <div className="n8n-assistant-body">
                <div className="mb-2 p-2 bg-secondary/50 rounded-md text-sm">
                  <div className="flex items-center gap-2">
                    <span>Using:</span>
                    <span className="font-medium">{getProvider().name}</span>
                  </div>
                </div>
                {messages.map(message => (
                  <div
                    key={message.id}
                    className={`n8n-assistant-message ${
                      message.sender === 'user' 
                        ? 'n8n-assistant-message-user' 
                        : 'n8n-assistant-message-bot'
                    }`}
                  >
                    {message.isLoading ? (
                      <div className="flex items-center gap-2">
                        <Loader size={16} className="animate-spin" />
                        <span>{message.content}</span>
                      </div>
                    ) : (
                      message.content
                    )}
                  </div>
                ))}
                <div ref={messagesEndRef} />
              </div>

              {/* Input area */}
              <div className="n8n-assistant-footer">
                <input
                  type="text"
                  value={inputValue}
                  onChange={(e) => setInputValue(e.target.value)}
                  onKeyDown={handleKeyDown}
                  placeholder="Ask about n8n..."
                  className="n8n-assistant-input"
                  disabled={isLoading}
                />
                <button 
                  onClick={handleSendMessage}
                  className="n8n-assistant-button"
                  disabled={isLoading || !inputValue.trim()}
                >
                  {isLoading ? <Loader size={18} className="animate-spin" /> : <Send size={18} />}
                </button>
              </div>
            </>
          )}
        </div>
      )}
    </div>
  );
};

export default ChatAssistant;
