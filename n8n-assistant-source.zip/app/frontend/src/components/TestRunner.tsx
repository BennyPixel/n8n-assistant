// src/components/TestRunner.tsx
import React, { useState } from 'react';
import { testService } from '../services/testService';

const TestRunner: React.FC = () => {
  const [testResults, setTestResults] = useState<any>(null);
  const [isRunningTests, setIsRunningTests] = useState(false);
  const [selectedScenario, setSelectedScenario] = useState<string>('');

  const runAllTests = async () => {
    setIsRunningTests(true);
    try {
      const results = await testService.runAllTests();
      setTestResults(results);
    } catch (error) {
      console.error('Error running tests:', error);
    } finally {
      setIsRunningTests(false);
    }
  };

  const runSelectedTest = async () => {
    if (!selectedScenario) return;
    
    setIsRunningTests(true);
    try {
      const result = await testService.runTestScenario(selectedScenario);
      setTestResults({ results: [result] });
    } catch (error) {
      console.error('Error running test scenario:', error);
    } finally {
      setIsRunningTests(false);
    }
  };

  return (
    <div className="p-4 bg-card rounded-lg shadow-lg max-w-4xl mx-auto">
      <h2 className="text-2xl font-bold mb-4">n8n Assistant Test Runner</h2>
      
      <div className="mb-6">
        <div className="flex gap-4 mb-4">
          <button
            onClick={runAllTests}
            disabled={isRunningTests}
            className="px-4 py-2 bg-primary text-primary-foreground rounded-md disabled:opacity-50"
          >
            {isRunningTests ? 'Running Tests...' : 'Run All Tests'}
          </button>
          
          <div className="flex-1 flex gap-2">
            <select
              value={selectedScenario}
              onChange={(e) => setSelectedScenario(e.target.value)}
              className="flex-1 rounded-md border bg-background px-3 py-2 text-sm"
              disabled={isRunningTests}
            >
              <option value="">Select a test scenario</option>
              {testService.scenarios.map(scenario => (
                <option key={scenario.id} value={scenario.id}>
                  {scenario.name}
                </option>
              ))}
            </select>
            
            <button
              onClick={runSelectedTest}
              disabled={isRunningTests || !selectedScenario}
              className="px-4 py-2 bg-primary text-primary-foreground rounded-md disabled:opacity-50"
            >
              Run Selected
            </button>
          </div>
        </div>
      </div>
      
      {testResults && (
        <div className="mt-6">
          <h3 className="text-xl font-semibold mb-2">Test Results</h3>
          
          {testResults.totalScenarios && (
            <div className="mb-4 p-3 bg-secondary rounded-md">
              <div className="grid grid-cols-3 gap-4 text-center">
                <div>
                  <div className="text-lg font-medium">{testResults.totalScenarios}</div>
                  <div className="text-sm text-muted-foreground">Total Scenarios</div>
                </div>
                <div>
                  <div className="text-lg font-medium text-green-500">{testResults.passedScenarios}</div>
                  <div className="text-sm text-muted-foreground">Passed</div>
                </div>
                <div>
                  <div className="text-lg font-medium text-red-500">{testResults.failedScenarios}</div>
                  <div className="text-sm text-muted-foreground">Failed</div>
                </div>
              </div>
            </div>
          )}
          
          <div className="space-y-4">
            {testResults.results && testResults.results.map((scenario: any) => (
              <div key={scenario.id} className={`p-4 rounded-md border ${scenario.passed ? 'border-green-500 bg-green-500/10' : 'border-red-500 bg-red-500/10'}`}>
                <div className="flex justify-between items-center mb-2">
                  <h4 className="font-medium">{scenario.name}</h4>
                  <span className={`px-2 py-1 rounded-full text-xs ${scenario.passed ? 'bg-green-500 text-white' : 'bg-red-500 text-white'}`}>
                    {scenario.passed ? 'PASSED' : 'FAILED'}
                  </span>
                </div>
                
                <div className="space-y-2 mt-3">
                  {scenario.steps && scenario.steps.map((step: any) => (
                    <div key={step.id} className={`p-3 rounded-md ${step.passed ? 'bg-green-500/5' : 'bg-red-500/5'}`}>
                      <div className="flex justify-between items-center">
                        <div className="text-sm font-medium">{step.description}</div>
                        <span className={`h-2 w-2 rounded-full ${step.passed ? 'bg-green-500' : 'bg-red-500'}`}></span>
                      </div>
                      
                      {step.error && (
                        <div className="mt-2 text-sm text-red-500 p-2 bg-red-500/10 rounded">
                          Error: {step.error}
                        </div>
                      )}
                      
                      {step.result && (
                        <div className="mt-2 text-xs text-muted-foreground">
                          <pre className="p-2 bg-secondary/50 rounded overflow-x-auto">
                            {JSON.stringify(step.result, null, 2)}
                          </pre>
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        </div>
      )}
    </div>
  );
};

export default TestRunner;
