import React, { useState, useEffect } from 'react';
import { validationService } from '../services/validationService';

const ValidationRunner: React.FC = () => {
  const [validationResults, setValidationResults] = useState<any>(null);
  const [isValidating, setIsValidating] = useState(false);
  const [selectedValidation, setSelectedValidation] = useState<string>('');

  const validationOptions = [
    { id: 'knowledgeBase', name: 'Knowledge Base Accuracy' },
    { id: 'errorHandling', name: 'Error Handling' },
    { id: 'promptTemplates', name: 'Prompt Templates' },
    { id: 'usability', name: 'Usability' },
    { id: 'all', name: 'All Validations' }
  ];

  const runAllValidations = async () => {
    setIsValidating(true);
    try {
      const results = await validationService.validateAll();
      setValidationResults(results);
    } catch (error) {
      console.error('Error running validations:', error);
    } finally {
      setIsValidating(false);
    }
  };

  const runSelectedValidation = async () => {
    if (!selectedValidation) return;
    
    setIsValidating(true);
    try {
      let result;
      
      switch (selectedValidation) {
        case 'knowledgeBase':
          result = await validationService.validateKnowledgeBaseAccuracy();
          setValidationResults({ knowledgeBase: result });
          break;
        case 'errorHandling':
          result = await validationService.validateErrorHandling();
          setValidationResults({ errorHandling: result });
          break;
        case 'promptTemplates':
          result = await validationService.validatePromptTemplates();
          setValidationResults({ promptTemplates: result });
          break;
        case 'usability':
          result = await validationService.validateUsability();
          setValidationResults({ usability: result });
          break;
        case 'all':
          runAllValidations();
          break;
      }
    } catch (error) {
      console.error('Error running validation:', error);
    } finally {
      setIsValidating(false);
    }
  };

  return (
    <div className="p-4 bg-card rounded-lg shadow-lg max-w-4xl mx-auto">
      <h2 className="text-2xl font-bold mb-4">n8n Assistant Validation</h2>
      
      <div className="mb-6">
        <div className="flex gap-4 mb-4">
          <button
            onClick={runAllValidations}
            disabled={isValidating}
            className="px-4 py-2 bg-primary text-primary-foreground rounded-md disabled:opacity-50"
          >
            {isValidating ? 'Running Validations...' : 'Validate All'}
          </button>
          
          <div className="flex-1 flex gap-2">
            <select
              value={selectedValidation}
              onChange={(e) => setSelectedValidation(e.target.value)}
              className="flex-1 rounded-md border bg-background px-3 py-2 text-sm"
              disabled={isValidating}
            >
              <option value="">Select validation type</option>
              {validationOptions.map(option => (
                <option key={option.id} value={option.id}>
                  {option.name}
                </option>
              ))}
            </select>
            
            <button
              onClick={runSelectedValidation}
              disabled={isValidating || !selectedValidation}
              className="px-4 py-2 bg-primary text-primary-foreground rounded-md disabled:opacity-50"
            >
              Run Selected
            </button>
          </div>
        </div>
      </div>
      
      {validationResults && (
        <div className="mt-6">
          <h3 className="text-xl font-semibold mb-2">Validation Results</h3>
          
          {validationResults.allPassed !== undefined && (
            <div className="mb-4 p-3 bg-secondary rounded-md">
              <div className="flex items-center justify-between">
                <span className="font-medium">Overall Validation:</span>
                <span className={`px-2 py-1 rounded-full text-xs ${validationResults.allPassed ? 'bg-green-500 text-white' : 'bg-red-500 text-white'}`}>
                  {validationResults.allPassed ? 'PASSED' : 'FAILED'}
                </span>
              </div>
            </div>
          )}
          
          <div className="space-y-4">
            {validationResults.knowledgeBase && (
              <ValidationResultCard
                title="Knowledge Base Accuracy"
                result={validationResults.knowledgeBase}
              />
            )}
            
            {validationResults.errorHandling && (
              <ValidationResultCard
                title="Error Handling"
                result={validationResults.errorHandling}
              />
            )}
            
            {validationResults.promptTemplates && (
              <ValidationResultCard
                title="Prompt Templates"
                result={validationResults.promptTemplates}
              />
            )}
            
            {validationResults.usability && (
              <ValidationResultCard
                title="Usability"
                result={validationResults.usability}
              />
            )}
          </div>
        </div>
      )}
    </div>
  );
};

interface ValidationResultCardProps {
  title: string;
  result: {
    passed: boolean;
    details: string;
    data?: any;
  };
}

const ValidationResultCard: React.FC<ValidationResultCardProps> = ({ title, result }) => {
  const [isExpanded, setIsExpanded] = useState(false);
  
  return (
    <div className={`p-4 rounded-md border ${result.passed ? 'border-green-500 bg-green-500/10' : 'border-red-500 bg-red-500/10'}`}>
      <div className="flex justify-between items-center mb-2">
        <h4 className="font-medium">{title}</h4>
        <span className={`px-2 py-1 rounded-full text-xs ${result.passed ? 'bg-green-500 text-white' : 'bg-red-500 text-white'}`}>
          {result.passed ? 'PASSED' : 'FAILED'}
        </span>
      </div>
      
      <p className="text-sm mb-2">{result.details}</p>
      
      {result.data && (
        <>
          <button
            onClick={() => setIsExpanded(!isExpanded)}
            className="text-sm text-primary underline"
          >
            {isExpanded ? 'Hide Details' : 'Show Details'}
          </button>
          
          {isExpanded && (
            <div className="mt-2 text-xs text-muted-foreground">
              <pre className="p-2 bg-secondary/50 rounded overflow-x-auto">
                {JSON.stringify(result.data, null, 2)}
              </pre>
            </div>
          )}
        </>
      )}
    </div>
  );
};

export default ValidationRunner;
