// src/hooks/useKnowledgeBase.tsx
import { useState } from 'react';
import { knowledgeBaseService } from '../services/knowledgeBaseService';

interface UseKnowledgeBaseResult {
  search: (query: string, options?: { limit?: number; category?: string }) => Promise<any>;
  isSearching: boolean;
  searchError: string | null;
  fallbackToWebSearch: (query: string) => Promise<string[]>;
  isWebSearching: boolean;
  webSearchError: string | null;
}

export const useKnowledgeBase = (): UseKnowledgeBaseResult => {
  const [isSearching, setIsSearching] = useState(false);
  const [searchError, setSearchError] = useState<string | null>(null);
  const [isWebSearching, setIsWebSearching] = useState(false);
  const [webSearchError, setWebSearchError] = useState<string | null>(null);

  const search = async (query: string, options: { limit?: number; category?: string } = {}) => {
    setIsSearching(true);
    setSearchError(null);
    
    try {
      const results = await knowledgeBaseService.search(query, options);
      return results;
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred';
      setSearchError(errorMessage);
      throw error;
    } finally {
      setIsSearching(false);
    }
  };

  const fallbackToWebSearch = async (query: string): Promise<string[]> => {
    setIsWebSearching(true);
    setWebSearchError(null);
    
    try {
      const results = await knowledgeBaseService.webSearch(query);
      return results;
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error occurred';
      setWebSearchError(errorMessage);
      throw error;
    } finally {
      setIsWebSearching(false);
    }
  };

  return {
    search,
    isSearching,
    searchError,
    fallbackToWebSearch,
    isWebSearching,
    webSearchError
  };
};
