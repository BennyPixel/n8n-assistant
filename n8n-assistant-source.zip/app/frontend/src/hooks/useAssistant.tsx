// src/hooks/useAssistant.tsx - Updated with knowledge base integration
import React, { useState, useEffect } from 'react';
import { useLLM } from '../contexts/LLMContext';
import { llmService } from '../services/llmService';
import { useKnowledgeBase } from './useKnowledgeBase';

// Define knowledge base service types
interface KnowledgeSearchResult {
  content: string;
  source: string;
  relevance: number;
}

// Hook for handling LLM interactions with context
export const useAssistant = () => {
  const { selectedProvider, apiKeys } = useLLM();
  const { search, fallbackToWebSearch } = useKnowledgeBase();
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Function to send message to LLM with knowledge base context
  const sendMessage = async (message: string): Promise<string> => {
    setIsLoading(true);
    setError(null);
    
    try {
      // Search knowledge base for relevant context
      const searchResults = await search(message, { limit: 3 });
      let context = '';
      
      // Format knowledge context if results found
      if (searchResults.items && searchResults.items.length > 0) {
        context = `Relevant n8n information:\n${searchResults.items.map(r => 
          `- ${r.title}: ${r.content} (Source: ${r.source})`
        ).join('\n')}`;
      } else {
        // Fallback to web search if no knowledge base results
        try {
          const webResults = await fallbackToWebSearch(message);
          if (webResults.length > 0) {
            context = `Web search results for n8n:\n${webResults.map(r => `- ${r}`).join('\n')}`;
          }
        } catch (webError) {
          console.error('Web search fallback failed:', webError);
          // Continue without web results if search fails
        }
      }
      
      // Create system prompt with instructions
      const systemPrompt = `
        You are a helpful assistant for n8n, a workflow automation tool.
        Your goal is to help users with JSON formatting, workflow error correction, prompt writing, and other n8n tasks.
        Be concise, accurate, and helpful. If you don't know something, say so rather than making up information.
        
        ${context}
      `;
      
      // Combine system prompt with user message
      const fullPrompt = `${systemPrompt}\n\nUser question: ${message}`;
      
      // Send to LLM service
      const response = await llmService.sendRequest({
        prompt: fullPrompt,
        providerId: selectedProvider,
        apiKey: apiKeys[selectedProvider] || '',
      });
      
      if (response.error) {
        setError(response.error);
        return `Error: ${response.error}`;
      }
      
      return response.text;
    } catch (err) {
      const errorMessage = err instanceof Error ? err.message : 'Unknown error occurred';
      setError(errorMessage);
      return `Sorry, an error occurred: ${errorMessage}`;
    } finally {
      setIsLoading(false);
    }
  };
  
  return {
    sendMessage,
    isLoading,
    error
  };
};
