import React, { useState, useEffect } from 'react';
import '../styles/globals.css';

// Define types for LLM providers
export interface LLMProvider {
  id: string;
  name: string;
  apiEndpoint: string;
  requiresApiKey: boolean;
}

// Define available LLM providers
export const llmProviders: LLMProvider[] = [
  {
    id: 'anthropic',
    name: 'Anthropic (Claude Sonnet 4)',
    apiEndpoint: '/api/llm/anthropic',
    requiresApiKey: true
  },
  {
    id: 'openai',
    name: 'OpenAI (GPT-4.1)',
    apiEndpoint: '/api/llm/openai',
    requiresApiKey: true
  }
];

// Create context for LLM provider settings
interface LLMContextType {
  selectedProvider: string;
  setSelectedProvider: (id: string) => void;
  apiKeys: Record<string, string>;
  setApiKey: (providerId: string, key: string) => void;
  getProvider: () => LLMProvider;
}

const defaultContext: LLMContextType = {
  selectedProvider: 'anthropic',
  setSelectedProvider: () => {},
  apiKeys: {},
  setApiKey: () => {},
  getProvider: () => llmProviders[0]
};

export const LLMContext = React.createContext<LLMContextType>(defaultContext);

// Provider component
export const LLMProvider: React.FC<{children: React.ReactNode}> = ({ children }) => {
  const [selectedProvider, setSelectedProvider] = useState<string>('anthropic');
  const [apiKeys, setApiKeys] = useState<Record<string, string>>({});

  // Load saved settings from localStorage on mount
  useEffect(() => {
    try {
      const savedProvider = localStorage.getItem('selectedLLMProvider');
      if (savedProvider) {
        setSelectedProvider(savedProvider);
      }

      const savedApiKeys = localStorage.getItem('llmApiKeys');
      if (savedApiKeys) {
        setApiKeys(JSON.parse(savedApiKeys));
      }
    } catch (error) {
      console.error('Error loading LLM settings:', error);
    }
  }, []);

  // Save settings to localStorage when they change
  useEffect(() => {
    try {
      localStorage.setItem('selectedLLMProvider', selectedProvider);
      localStorage.setItem('llmApiKeys', JSON.stringify(apiKeys));
    } catch (error) {
      console.error('Error saving LLM settings:', error);
    }
  }, [selectedProvider, apiKeys]);

  const setApiKey = (providerId: string, key: string) => {
    setApiKeys(prev => ({
      ...prev,
      [providerId]: key
    }));
  };

  const getProvider = (): LLMProvider => {
    return llmProviders.find(p => p.id === selectedProvider) || llmProviders[0];
  };

  return (
    <LLMContext.Provider 
      value={{ 
        selectedProvider, 
        setSelectedProvider, 
        apiKeys, 
        setApiKey,
        getProvider
      }}
    >
      {children}
    </LLMContext.Provider>
  );
};

// Custom hook for using the LLM context
export const useLLM = () => React.useContext(LLMContext);
