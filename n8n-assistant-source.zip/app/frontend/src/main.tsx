import React from 'react';
import { createRoot } from 'react-dom/client';
import './styles/globals.css';
import ChatAssistant from './components/ChatAssistant';
import { LLMProvider } from './contexts/LLMContext';
import { ThemeProvider } from './contexts/ThemeContext';

const App: React.FC = () => {
  return (
    <ThemeProvider>
      <LLMProvider>
        <ChatAssistant />
      </LLMProvider>
    </ThemeProvider>
  );
};

const container = document.getElementById('root');
const root = createRoot(container!);
root.render(<App />);
