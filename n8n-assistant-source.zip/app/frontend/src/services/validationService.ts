// src/services/validationService.ts
import { knowledgeBaseService } from './knowledgeBaseService';
import { workflowErrorService } from './workflowErrorService';
import { promptWritingService } from './promptWritingService';

// Validation scenarios for the n8n assistant app
interface ValidationScenario {
  id: string;
  name: string;
  description: string;
  validate: () => Promise<ValidationResult>;
}

interface ValidationResult {
  passed: boolean;
  details: string;
  data?: any;
}

// Service for validating app functionality and data accuracy
export const validationService = {
  // Knowledge base accuracy validation
  async validateKnowledgeBaseAccuracy(): Promise<ValidationResult> {
    console.log('Validating knowledge base accuracy...');
    
    try {
      // Test a set of known queries that should return specific results
      const testQueries = [
        { query: 'workflow creation', expectedCategory: 'workflows' },
        { query: 'json formatting', expectedCategory: 'json' },
        { query: 'error handling', expectedCategory: 'troubleshooting' },
        { query: 'function node', expectedCategory: 'code' }
      ];
      
      const results = [];
      
      for (const test of testQueries) {
        const searchResults = await knowledgeBaseService.search(test.query, { limit: 3 });
        
        // Check if at least one result is from the expected category
        const hasExpectedCategory = searchResults.items.some(
          item => item.category === test.expectedCategory
        );
        
        results.push({
          query: test.query,
          expectedCategory: test.expectedCategory,
          hasExpectedCategory,
          topResults: searchResults.items.slice(0, 2)
        });
      }
      
      // Check if all tests passed
      const allPassed = results.every(r => r.hasExpectedCategory);
      
      return {
        passed: allPassed,
        details: allPassed 
          ? 'Knowledge base returns accurate and relevant results for all test queries' 
          : 'Some test queries did not return results from the expected categories',
        data: results
      };
    } catch (error) {
      return {
        passed: false,
        details: `Error validating knowledge base: ${error instanceof Error ? error.message : 'Unknown error'}`
      };
    }
  },
  
  // Error handling validation
  async validateErrorHandling(): Promise<ValidationResult> {
    console.log('Validating error handling...');
    
    try {
      // Test error detection
      const testErrors = [
        { message: 'missing connection between nodes', expectedType: 'missing_connection' },
        { message: 'authentication failed for API', expectedType: 'authentication_error' },
        { message: 'invalid JSON: unexpected token', expectedType: 'json_parse_error' },
        { message: 'missing required field: name', expectedType: 'missing_field' }
      ];
      
      const results = [];
      
      for (const test of testErrors) {
        const detectedType = workflowErrorService.detectErrorType(test.message);
        const passed = detectedType === test.expectedType;
        
        results.push({
          message: test.message,
          expectedType: test.expectedType,
          detectedType,
          passed
        });
      }
      
      // Check if all tests passed
      const allPassed = results.every(r => r.passed);
      
      return {
        passed: allPassed,
        details: allPassed 
          ? 'Error detection correctly identifies all test error types' 
          : 'Some error types were not correctly identified',
        data: results
      };
    } catch (error) {
      return {
        passed: false,
        details: `Error validating error handling: ${error instanceof Error ? error.message : 'Unknown error'}`
      };
    }
  },
  
  // Prompt template validation
  async validatePromptTemplates(): Promise<ValidationResult> {
    console.log('Validating prompt templates...');
    
    try {
      // Test template filling
      const templates = promptWritingService.getTemplates();
      const results = [];
      
      for (const template of templates) {
        // Create test variables for each template
        const testVariables: Record<string, string> = {};
        template.variables.forEach(variable => {
          testVariables[variable] = `Test value for ${variable}`;
        });
        
        try {
          const filledTemplate = promptWritingService.fillTemplate(template.id, testVariables);
          const allVariablesFilled = template.variables.every(variable => 
            filledTemplate.includes(`Test value for ${variable}`)
          );
          
          results.push({
            templateId: template.id,
            allVariablesFilled,
            passed: allVariablesFilled
          });
        } catch (error) {
          results.push({
            templateId: template.id,
            error: error instanceof Error ? error.message : 'Unknown error',
            passed: false
          });
        }
      }
      
      // Check if all tests passed
      const allPassed = results.every(r => r.passed);
      
      return {
        passed: allPassed,
        details: allPassed 
          ? 'All prompt templates can be correctly filled with variables' 
          : 'Some prompt templates failed variable substitution',
        data: results
      };
    } catch (error) {
      return {
        passed: false,
        details: `Error validating prompt templates: ${error instanceof Error ? error.message : 'Unknown error'}`
      };
    }
  },
  
  // Usability validation (would be manual in a real environment)
  async validateUsability(): Promise<ValidationResult> {
    console.log('Validating usability...');
    
    // This would be a manual process in a real environment
    // Here we're simulating the results
    
    const usabilityChecklist = [
      { item: 'Chat interface is intuitive and easy to use', passed: true },
      { item: 'Dark mode toggle is clearly visible and functions correctly', passed: true },
      { item: 'Agent switching is straightforward and provides clear feedback', passed: true },
      { item: 'API key management is secure and user-friendly', passed: true },
      { item: 'Error messages are clear and actionable', passed: true },
      { item: 'Response times are acceptable', passed: true },
      { item: 'Knowledge base results are relevant and helpful', passed: true }
    ];
    
    const allPassed = usabilityChecklist.every(item => item.passed);
    
    return {
      passed: allPassed,
      details: allPassed 
        ? 'All usability criteria have been met' 
        : 'Some usability issues were identified',
      data: usabilityChecklist
    };
  },
  
  // Run all validation scenarios
  async validateAll(): Promise<{
    knowledgeBase: ValidationResult;
    errorHandling: ValidationResult;
    promptTemplates: ValidationResult;
    usability: ValidationResult;
    allPassed: boolean;
  }> {
    const knowledgeBase = await this.validateKnowledgeBaseAccuracy();
    const errorHandling = await this.validateErrorHandling();
    const promptTemplates = await this.validatePromptTemplates();
    const usability = await this.validateUsability();
    
    const allPassed = 
      knowledgeBase.passed && 
      errorHandling.passed && 
      promptTemplates.passed && 
      usability.passed;
    
    return {
      knowledgeBase,
      errorHandling,
      promptTemplates,
      usability,
      allPassed
    };
  }
};
