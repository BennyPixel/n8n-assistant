// src/services/knowledgeBaseService.ts
import axios from 'axios';

interface KnowledgeItem {
  id: string;
  category: string;
  title: string;
  content: string;
  source: string;
  relevance?: number;
}

interface SearchResult {
  items: KnowledgeItem[];
  totalResults: number;
  searchTime: number;
}

// Mock knowledge base data
const mockKnowledgeBase: KnowledgeItem[] = [
  {
    id: 'kb-001',
    category: 'workflows',
    title: 'Creating Your First Workflow',
    content: 'n8n workflows can be triggered manually or automatically based on events. To create your first workflow, click on "Create new" in the n8n interface. Add a trigger node to start your workflow, then add action nodes to process data and perform operations.',
    source: 'workflows/getting-started.md'
  },
  {
    id: 'kb-002',
    category: 'json',
    title: 'Working with JSON in n8n',
    content: 'JSON nodes in n8n allow you to transform data between different formats. Use the JSON Parse node to convert strings to JSON objects, and the JSON Stringify node to convert JSON objects to strings. For more complex transformations, you can use the Function node with JavaScript.',
    source: 'json/formatting.md'
  },
  {
    id: 'kb-003',
    category: 'troubleshooting',
    title: 'Common Workflow Errors',
    content: 'Common workflow errors include missing connections between nodes, invalid data types, authentication failures, and timeout issues. Check node connections, verify input data formats, ensure credentials are valid, and consider increasing timeout values for long-running operations.',
    source: 'troubleshooting/common-errors.md'
  },
  {
    id: 'kb-004',
    category: 'ai',
    title: 'Using AI Nodes in n8n',
    content: 'n8n provides several AI-related nodes for integrating with services like OpenAI, Anthropic, and others. These nodes allow you to generate text, analyze sentiment, classify content, and more. Make sure to configure your API credentials in the n8n credentials manager.',
    source: 'advanced-ai/nodes.md'
  },
  {
    id: 'kb-005',
    category: 'code',
    title: 'Writing JavaScript in Function Nodes',
    content: 'Function nodes in n8n allow you to write custom JavaScript code to transform data. You can access the incoming data using the `items` variable, and you must return an array of items. Use `item.json` to access JSON data from previous nodes.',
    source: 'code/function-nodes.md'
  },
  {
    id: 'kb-006',
    category: 'integrations',
    title: 'Connecting to External APIs',
    content: 'Use the HTTP Request node to connect to external APIs. Configure the method (GET, POST, etc.), URL, headers, and body as needed. For authenticated APIs, you can use the n8n credentials manager to securely store your API keys and tokens.',
    source: 'integrations/http-request.md'
  },
  {
    id: 'kb-007',
    category: 'workflows',
    title: 'Error Handling in Workflows',
    content: 'Implement error handling in your workflows using the Error Trigger node, which catches errors from other nodes. You can then send notifications, log errors, or take corrective actions. Use the IF node to check for specific error conditions.',
    source: 'workflows/error-handling.md'
  },
  {
    id: 'kb-008',
    category: 'json',
    title: 'Fixing Invalid JSON',
    content: 'When dealing with invalid JSON, use the Function node to clean and repair the data. Common issues include missing quotes, trailing commas, and unescaped characters. You can use try-catch blocks to handle parsing errors gracefully.',
    source: 'json/troubleshooting.md'
  },
  {
    id: 'kb-009',
    category: 'troubleshooting',
    title: 'Debugging Workflows',
    content: 'Debug n8n workflows by using the console.log() function in Function nodes, checking execution data in the execution history, and using the IF node to conditionally process data based on its structure or content.',
    source: 'troubleshooting/debugging.md'
  },
  {
    id: 'kb-010',
    category: 'ai',
    title: 'Prompt Engineering for AI Nodes',
    content: 'When working with AI nodes in n8n, craft effective prompts by being specific, providing context, and using examples. Structure your prompts with clear instructions and use system messages to set the tone and behavior of the AI assistant.',
    source: 'advanced-ai/prompt-engineering.md'
  }
];

// Service for handling knowledge base operations
export const knowledgeBaseService = {
  // Search the knowledge base
  async search(query: string, options: { limit?: number; category?: string } = {}): Promise<SearchResult> {
    console.log('Searching knowledge base for:', query, options);
    
    const startTime = Date.now();
    
    // This is a mock implementation - in production, this would search a real database
    return new Promise((resolve) => {
      setTimeout(() => {
        // Filter by category if specified
        let results = [...mockKnowledgeBase];
        if (options.category) {
          results = results.filter(item => item.category === options.category);
        }
        
        // Simple relevance scoring based on term frequency
        const queryTerms = query.toLowerCase().split(/\s+/);
        results = results.map(item => {
          const content = (item.title + ' ' + item.content).toLowerCase();
          let relevance = 0;
          
          queryTerms.forEach(term => {
            const regex = new RegExp(term, 'gi');
            const matches = content.match(regex);
            if (matches) {
              relevance += matches.length;
            }
          });
          
          return { ...item, relevance };
        });
        
        // Sort by relevance
        results = results
          .filter(item => item.relevance && item.relevance > 0)
          .sort((a, b) => (b.relevance || 0) - (a.relevance || 0));
        
        // Apply limit
        if (options.limit) {
          results = results.slice(0, options.limit);
        }
        
        const searchTime = (Date.now() - startTime) / 1000;
        
        resolve({
          items: results,
          totalResults: results.length,
          searchTime
        });
      }, 300); // Simulate search delay
    });
  },
  
  // Get a specific knowledge item by ID
  async getById(id: string): Promise<KnowledgeItem | null> {
    console.log('Getting knowledge item by ID:', id);
    
    // This is a mock implementation - in production, this would fetch from a real database
    return new Promise((resolve) => {
      setTimeout(() => {
        const item = mockKnowledgeBase.find(item => item.id === id) || null;
        resolve(item);
      }, 100);
    });
  },
  
  // Fallback to web search when knowledge base doesn't have answers
  async webSearch(query: string): Promise<string[]> {
    console.log('Falling back to web search for:', query);
    
    // This is a mock implementation - in production, this would use a real search API
    return new Promise((resolve) => {
      setTimeout(() => {
        resolve([
          `Web search result for "${query}" - n8n documentation page`,
          `Web search result for "${query}" - n8n community forum thread`,
          `Web search result for "${query}" - n8n blog article`
        ]);
      }, 500);
    });
  }
};
