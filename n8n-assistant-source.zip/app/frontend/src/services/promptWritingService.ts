// src/services/promptWritingService.ts
import { llmService } from './llmService';

interface PromptTemplate {
  id: string;
  name: string;
  description: string;
  template: string;
  variables: string[];
}

interface PromptGenerationResult {
  prompt: string;
  explanation?: string;
  error?: string;
}

// Service for handling prompt writing assistance
export const promptWritingService = {
  // Predefined prompt templates for common n8n use cases
  templates: [
    {
      id: 'workflow_generation',
      name: 'Workflow Generation',
      description: 'Generate an n8n workflow based on a specific task',
      template: `Create an n8n workflow that accomplishes the following task: {{task}}. 
The workflow should include appropriate triggers, processing steps, and actions.
Consider error handling and edge cases.
Provide the workflow as a step-by-step guide with node configurations.`,
      variables: ['task']
    },
    {
      id: 'data_transformation',
      name: 'Data Transformation',
      description: 'Transform data from one format to another',
      template: `I have data in the following format: {{input_format}}
Example: {{input_example}}

I need to transform it to this format: {{output_format}}
Example of desired output: {{output_example}}

Please provide the JavaScript code or JSON transformation steps I should use in n8n to accomplish this.`,
      variables: ['input_format', 'input_example', 'output_format', 'output_example']
    },
    {
      id: 'api_integration',
      name: 'API Integration',
      description: 'Connect to and use an external API',
      template: `I need to integrate with the following API in n8n:
API Name: {{api_name}}
API Documentation URL: {{api_url}}
Specific Endpoint: {{endpoint}}
Authentication Method: {{auth_method}}

What I'm trying to accomplish: {{goal}}

Please provide step-by-step instructions for setting up this integration in n8n, including any required credentials, HTTP Request node configuration, and data handling.`,
      variables: ['api_name', 'api_url', 'endpoint', 'auth_method', 'goal']
    },
    {
      id: 'error_handling',
      name: 'Error Handling Strategy',
      description: 'Design error handling for a workflow',
      template: `I need to implement error handling for an n8n workflow that {{workflow_description}}.

Potential errors that might occur:
{{potential_errors}}

How should I structure my workflow to handle these errors gracefully? Please include:
1. Recommended error detection methods
2. Error handling nodes to use
3. Recovery strategies
4. Notification setup if errors occur`,
      variables: ['workflow_description', 'potential_errors']
    },
    {
      id: 'custom_function',
      name: 'Custom Function Node',
      description: 'Create a custom function for data processing',
      template: `I need to write a custom function in n8n's Function node to accomplish the following:
Task: {{task}}

Input data structure:
{{input_structure}}

Desired output structure:
{{output_structure}}

Any special considerations or edge cases:
{{considerations}}

Please provide the JavaScript code I should use in the Function node.`,
      variables: ['task', 'input_structure', 'output_structure', 'considerations']
    }
  ],

  // Get all available templates
  getTemplates(): PromptTemplate[] {
    return this.templates;
  },

  // Get a specific template by ID
  getTemplateById(id: string): PromptTemplate | undefined {
    return this.templates.find(template => template.id === id);
  },

  // Fill a template with provided variables
  fillTemplate(templateId: string, variables: Record<string, string>): string {
    const template = this.getTemplateById(templateId);
    if (!template) {
      throw new Error(`Template with ID "${templateId}" not found`);
    }

    let filledTemplate = template.template;
    for (const key of Object.keys(variables)) {
      const placeholder = `{{${key}}}`;
      filledTemplate = filledTemplate.replace(new RegExp(placeholder, 'g'), variables[key]);
    }

    return filledTemplate;
  },

  // Generate a prompt using LLM to optimize it
  async generateOptimizedPrompt(
    basePrompt: string,
    providerId: string,
    apiKey: string
  ): Promise<PromptGenerationResult> {
    const prompt = `
      You are an expert at writing effective prompts for AI systems. 
      Please optimize the following prompt to be more effective, clear, and likely to produce good results:

      ORIGINAL PROMPT:
      """
      ${basePrompt}
      """

      Your task:
      1. Analyze the original prompt
      2. Improve its structure, clarity, and specificity
      3. Add any missing context or details that would help
      4. Remove any ambiguities or confusing elements
      5. Return the optimized prompt

      Format your response with:
      OPTIMIZED PROMPT:
      [Your improved prompt here]

      EXPLANATION:
      [Brief explanation of what you improved and why]
    `;

    try {
      const response = await llmService.sendRequest({
        prompt,
        providerId,
        apiKey
      });

      if (response.error) {
        return {
          prompt: basePrompt,
          error: response.error
        };
      }

      // Extract the optimized prompt and explanation
      const optimizedMatch = response.text.match(/OPTIMIZED PROMPT:\s*([\s\S]*?)(?:EXPLANATION:|$)/i);
      const explanationMatch = response.text.match(/EXPLANATION:\s*([\s\S]*?)$/i);

      return {
        prompt: optimizedMatch ? optimizedMatch[1].trim() : basePrompt,
        explanation: explanationMatch ? explanationMatch[1].trim() : undefined
      };
    } catch (error) {
      console.error('Error generating optimized prompt:', error);
      return {
        prompt: basePrompt,
        error: error instanceof Error ? error.message : 'Unknown error occurred'
      };
    }
  }
};
