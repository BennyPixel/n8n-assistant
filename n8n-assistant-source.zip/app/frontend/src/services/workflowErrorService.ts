// src/services/workflowErrorService.ts
import { llmService } from './llmService';

interface WorkflowError {
  type: string;
  message: string;
  nodeId?: string;
  details?: string;
}

interface ErrorCorrectionResult {
  suggestion: string;
  code?: string;
  explanation: string;
}

// Service for handling workflow error detection and correction
export const workflowErrorService = {
  // Common n8n workflow error patterns
  errorPatterns: [
    {
      type: 'missing_connection',
      regex: /missing connection/i,
      description: 'Node is missing a required connection to another node'
    },
    {
      type: 'invalid_data',
      regex: /invalid data/i,
      description: 'Data format is incorrect or incompatible'
    },
    {
      type: 'authentication_error',
      regex: /authentication (failed|error)/i,
      description: 'Authentication credentials are invalid or expired'
    },
    {
      type: 'missing_field',
      regex: /missing (required )?field/i,
      description: 'A required field is missing in the node configuration'
    },
    {
      type: 'json_parse_error',
      regex: /(json parse error|invalid json)/i,
      description: 'JSON data could not be parsed correctly'
    }
  ],

  // Detect error type from error message
  detectErrorType(errorMessage: string): string {
    for (const pattern of this.errorPatterns) {
      if (pattern.regex.test(errorMessage)) {
        return pattern.type;
      }
    }
    return 'unknown_error';
  },

  // Get error description
  getErrorDescription(errorType: string): string {
    const pattern = this.errorPatterns.find(p => p.type === errorType);
    return pattern ? pattern.description : 'Unknown error type';
  },

  // Generate correction suggestion using LLM
  async generateCorrection(
    error: WorkflowError,
    workflowContext: string,
    providerId: string,
    apiKey: string
  ): Promise<ErrorCorrectionResult> {
    const errorType = this.detectErrorType(error.message);
    const errorDescription = this.getErrorDescription(errorType);
    
    const prompt = `
      You are an expert n8n workflow troubleshooter. Help fix the following error:
      
      Error Type: ${errorType}
      Error Description: ${errorDescription}
      Error Message: ${error.message}
      ${error.details ? `Additional Details: ${error.details}` : ''}
      ${error.nodeId ? `Node ID: ${error.nodeId}` : ''}
      
      Workflow Context:
      ${workflowContext}
      
      Provide a detailed suggestion to fix this error. If code is needed, include it in your response.
      Format your response with:
      1. A clear explanation of what's wrong
      2. Step-by-step instructions to fix it
      3. Any code snippets needed (if applicable)
    `;
    
    try {
      const response = await llmService.sendRequest({
        prompt,
        providerId,
        apiKey
      });
      
      if (response.error) {
        throw new Error(response.error);
      }
      
      // Extract code if present (simple extraction - could be more sophisticated)
      const codeMatch = response.text.match(/```(?:json|javascript)?\s*([\s\S]*?)\s*```/);
      const code = codeMatch ? codeMatch[1].trim() : undefined;
      
      return {
        suggestion: response.text,
        code,
        explanation: response.text.replace(/```(?:json|javascript)?\s*[\s\S]*?\s*```/g, '[Code snippet removed for clarity]')
      };
    } catch (error) {
      console.error('Error generating correction:', error);
      return {
        suggestion: 'Unable to generate correction suggestion.',
        explanation: `Error: ${error instanceof Error ? error.message : 'Unknown error'}`
      };
    }
  },
  
  // Sample workflow context extraction (would be replaced with actual DOM manipulation)
  extractWorkflowContext(): string {
    // This would be implemented to extract the current workflow context from the n8n UI
    // For now, return a sample context
    return `
      Workflow: "Process Customer Data"
      Nodes:
      1. HTTP Request - Fetches customer data from API
      2. JSON Parse - Parses the response
      3. Function - Transforms data
      4. Set - Sets variables for later use
      5. IF - Conditional logic based on customer type
      6. Webhook - Sends processed data to external system
    `;
  }
};
