// src/services/llmService.ts
import axios from 'axios';

interface LLMRequestParams {
  prompt: string;
  providerId: string;
  apiKey: string;
  context?: string;
}

interface LLMResponse {
  text: string;
  error?: string;
}

// Service for handling LLM API requests
export const llmService = {
  // Send request to Anthropic Claude API
  async sendToAnthropic({ prompt, apiKey, context = '' }: LLMRequestParams): Promise<LLMResponse> {
    try {
      // This is a mock implementation - in production, this would call the actual Anthropic API
      console.log('Sending to Anthropic API:', { prompt, contextLength: context.length });
      
      // Simulate API call
      return new Promise((resolve) => {
        setTimeout(() => {
          resolve({
            text: `This is a simulated response from Claude. Your prompt was: "${prompt}". In a real implementation, this would connect to the Anthropic API with your key.`
          });
        }, 1000);
      });
    } catch (error) {
      console.error('Error calling Anthropic API:', error);
      return {
        text: '',
        error: 'Failed to connect to Anthropic API. Please check your API key and try again.'
      };
    }
  },

  // Send request to OpenAI API
  async sendToOpenAI({ prompt, apiKey, context = '' }: LLMRequestParams): Promise<LLMResponse> {
    try {
      // This is a mock implementation - in production, this would call the actual OpenAI API
      console.log('Sending to OpenAI API:', { prompt, contextLength: context.length });
      
      // Simulate API call
      return new Promise((resolve) => {
        setTimeout(() => {
          resolve({
            text: `This is a simulated response from GPT-4. Your prompt was: "${prompt}". In a real implementation, this would connect to the OpenAI API with your key.`
          });
        }, 1000);
      });
    } catch (error) {
      console.error('Error calling OpenAI API:', error);
      return {
        text: '',
        error: 'Failed to connect to OpenAI API. Please check your API key and try again.'
      };
    }
  },

  // Route request to appropriate provider
  async sendRequest({ prompt, providerId, apiKey, context }: LLMRequestParams): Promise<LLMResponse> {
    if (!apiKey) {
      return {
        text: '',
        error: 'API key is required. Please add your API key in the settings.'
      };
    }

    switch (providerId) {
      case 'anthropic':
        return this.sendToAnthropic({ prompt, apiKey, context });
      case 'openai':
        return this.sendToOpenAI({ prompt, apiKey, context });
      default:
        return {
          text: '',
          error: `Unknown provider: ${providerId}`
        };
    }
  }
};
