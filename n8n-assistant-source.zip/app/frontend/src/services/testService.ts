// src/services/testService.ts
import { knowledgeBaseService } from './knowledgeBaseService';
import { llmService } from './llmService';
import { workflowErrorService } from './workflowErrorService';
import { promptWritingService } from './promptWritingService';

// Test scenarios for the n8n assistant app
interface TestScenario {
  id: string;
  name: string;
  description: string;
  steps: TestStep[];
}

interface TestStep {
  id: string;
  description: string;
  action: () => Promise<any>;
  expectedResult: string;
}

// Service for testing the app within n8n
export const testService = {
  // Test scenarios
  scenarios: [
    {
      id: 'basic-chat',
      name: 'Basic Chat Functionality',
      description: 'Tests the basic chat interface and response generation',
      steps: [
        {
          id: 'basic-chat-1',
          description: 'Send a simple greeting message',
          action: async () => {
            const mockApiKey = 'test-api-key';
            const response = await llmService.sendRequest({
              prompt: 'Hello, can you help me with n8n?',
              providerId: 'anthropic',
              apiKey: mockApiKey
            });
            return response;
          },
          expectedResult: 'Assistant should respond with a helpful greeting'
        }
      ]
    },
    {
      id: 'knowledge-retrieval',
      name: 'Knowledge Base Retrieval',
      description: 'Tests the knowledge base search functionality',
      steps: [
        {
          id: 'knowledge-1',
          description: 'Search for information about workflows',
          action: async () => {
            const results = await knowledgeBaseService.search('how to create a workflow', { limit: 3 });
            return results;
          },
          expectedResult: 'Should return relevant workflow information from the knowledge base'
        },
        {
          id: 'knowledge-2',
          description: 'Search for non-existent information and test fallback',
          action: async () => {
            const results = await knowledgeBaseService.search('something very specific and unlikely to be found', { limit: 3 });
            if (results.items.length === 0) {
              return await knowledgeBaseService.webSearch('something very specific and unlikely to be found');
            }
            return results;
          },
          expectedResult: 'Should fallback to web search when knowledge base has no results'
        }
      ]
    },
    {
      id: 'error-correction',
      name: 'Workflow Error Correction',
      description: 'Tests the workflow error detection and correction functionality',
      steps: [
        {
          id: 'error-1',
          description: 'Detect and suggest fix for a JSON parse error',
          action: async () => {
            const mockApiKey = 'test-api-key';
            const error = {
              type: 'json_parse_error',
              message: 'Invalid JSON: Unexpected token } in JSON at position 52',
              nodeId: 'JSON Parse',
              details: '{"name": "John", "age": 30,, "city": "New York"}'
            };
            const workflowContext = workflowErrorService.extractWorkflowContext();
            const correction = await workflowErrorService.generateCorrection(
              error,
              workflowContext,
              'anthropic',
              mockApiKey
            );
            return correction;
          },
          expectedResult: 'Should identify the extra comma in the JSON and suggest a fix'
        }
      ]
    },
    {
      id: 'prompt-writing',
      name: 'Prompt Writing Assistance',
      description: 'Tests the prompt writing and optimization functionality',
      steps: [
        {
          id: 'prompt-1',
          description: 'Generate a workflow creation prompt using a template',
          action: async () => {
            const templateId = 'workflow_generation';
            const variables = {
              task: 'Send a daily email with weather forecast data'
            };
            const filledTemplate = promptWritingService.fillTemplate(templateId, variables);
            return filledTemplate;
          },
          expectedResult: 'Should generate a complete prompt for workflow creation with the specified task'
        },
        {
          id: 'prompt-2',
          description: 'Optimize a basic prompt',
          action: async () => {
            const mockApiKey = 'test-api-key';
            const basePrompt = 'Create a workflow that gets weather data and sends email';
            const optimizedPrompt = await promptWritingService.generateOptimizedPrompt(
              basePrompt,
              'anthropic',
              mockApiKey
            );
            return optimizedPrompt;
          },
          expectedResult: 'Should return an optimized version of the prompt with more details and structure'
        }
      ]
    },
    {
      id: 'ui-integration',
      name: 'UI Integration Tests',
      description: 'Tests the UI integration within n8n',
      steps: [
        {
          id: 'ui-1',
          description: 'Verify dark mode toggle functionality',
          action: async () => {
            // This would be implemented with actual DOM testing in a real environment
            return { success: true, message: 'Dark mode toggle changes theme correctly' };
          },
          expectedResult: 'UI should switch between dark and light modes correctly'
        },
        {
          id: 'ui-2',
          description: 'Verify agent switching functionality',
          action: async () => {
            // This would be implemented with actual DOM testing in a real environment
            return { success: true, message: 'Agent switching updates the active LLM provider' };
          },
          expectedResult: 'UI should update to show the selected AI agent and use it for responses'
        }
      ]
    }
  ],
  
  // Run all test scenarios
  async runAllTests(): Promise<{
    totalScenarios: number;
    passedScenarios: number;
    failedScenarios: number;
    results: any[];
  }> {
    console.log('Running all test scenarios...');
    
    const results = [];
    let passedScenarios = 0;
    let failedScenarios = 0;
    
    for (const scenario of this.scenarios) {
      console.log(`Running scenario: ${scenario.name}`);
      
      const scenarioResult = {
        id: scenario.id,
        name: scenario.name,
        steps: [],
        passed: true
      };
      
      for (const step of scenario.steps) {
        console.log(`  Step: ${step.description}`);
        
        try {
          const result = await step.action();
          scenarioResult.steps.push({
            id: step.id,
            description: step.description,
            result,
            passed: true
          });
        } catch (error) {
          console.error(`  Error in step ${step.id}:`, error);
          scenarioResult.steps.push({
            id: step.id,
            description: step.description,
            error: error instanceof Error ? error.message : 'Unknown error',
            passed: false
          });
          scenarioResult.passed = false;
        }
      }
      
      if (scenarioResult.passed) {
        passedScenarios++;
      } else {
        failedScenarios++;
      }
      
      results.push(scenarioResult);
    }
    
    return {
      totalScenarios: this.scenarios.length,
      passedScenarios,
      failedScenarios,
      results
    };
  },
  
  // Run a specific test scenario by ID
  async runTestScenario(scenarioId: string): Promise<any> {
    const scenario = this.scenarios.find(s => s.id === scenarioId);
    
    if (!scenario) {
      throw new Error(`Test scenario with ID "${scenarioId}" not found`);
    }
    
    console.log(`Running scenario: ${scenario.name}`);
    
    const scenarioResult = {
      id: scenario.id,
      name: scenario.name,
      steps: [],
      passed: true
    };
    
    for (const step of scenario.steps) {
      console.log(`  Step: ${step.description}`);
      
      try {
        const result = await step.action();
        scenarioResult.steps.push({
          id: step.id,
          description: step.description,
          result,
          passed: true
        });
      } catch (error) {
        console.error(`  Error in step ${step.id}:`, error);
        scenarioResult.steps.push({
          id: step.id,
          description: step.description,
          error: error instanceof Error ? error.message : 'Unknown error',
          passed: false
        });
        scenarioResult.passed = false;
      }
    }
    
    return scenarioResult;
  }
};
