# n8n Context-Aware Assistant - Deployment Guide

## Overview

This document provides instructions for deploying the n8n Context-Aware Assistant, a lightweight app that integrates with your n8n instance to provide assistance with JSON formatting, workflow error correction, prompt writing, and more.

## Features

- **Dark Mode UI**: Sleek, modern interface with green accent colors
- **Interchangeable AI Agents**: Switch between different LLM providers (Claude, GPT)
- **API Key Management**: Securely store and manage your API keys
- **Context-Aware Assistance**: Get help with n8n-specific tasks
- **Knowledge Base**: Built-in knowledge from n8n documentation
- **Web Search Fallback**: Automatic fallback to web search when needed
- **Error Correction**: Intelligent workflow error detection and correction
- **Prompt Templates**: Pre-built templates for common n8n tasks

## Prerequisites

- n8n instance (self-hosted or cloud)
- API keys for at least one LLM provider (Anthropic Claude and/or OpenAI GPT)
- Node.js 16+ and npm/pnpm

## Installation

1. **Extract the deployment package**:
   ```bash
   unzip n8n-assistant.zip -d /path/to/your/n8n/custom/extensions/
   ```

2. **Install dependencies**:
   ```bash
   cd /path/to/your/n8n/custom/extensions/n8n-assistant
   pnpm install
   ```

3. **Build the application**:
   ```bash
   pnpm build
   ```

4. **Configure n8n to load the extension**:
   Add the following to your n8n configuration file or environment variables:
   ```
   N8N_CUSTOM_EXTENSIONS=/path/to/your/n8n/custom/extensions/n8n-assistant
   ```

5. **Restart your n8n instance**:
   ```bash
   pm2 restart n8n # or however you manage your n8n process
   ```

## Usage

1. **Access the assistant**:
   - The assistant will appear as a chat icon in the bottom right corner of your n8n workflow editor
   - Click the icon to open the chat interface

2. **Configure your API keys**:
   - Click the settings icon in the chat header
   - Enter your API keys for the LLM providers you want to use
   - Select your preferred provider

3. **Using the assistant**:
   - Ask questions about n8n workflows, JSON formatting, etc.
   - Share error messages to get correction suggestions
   - Request prompt templates for common tasks
   - Toggle between dark and light mode using the theme button

## Troubleshooting

- **Assistant not appearing**: Ensure the extension path is correctly configured and n8n has been restarted
- **LLM responses not working**: Verify your API keys are correctly entered and the selected provider is available
- **Knowledge base issues**: The internal knowledge base can be refreshed by restarting the extension

## Security Notes

- API keys are stored in your browser's localStorage and are not sent to any external servers
- All LLM requests are made directly from your browser to the provider's API
- No data is collected or shared outside your n8n instance

## Support

This app is for personal use only and not for public distribution. For any issues or questions, please contact the developer directly.

## License

This application is provided for personal use only and is not licensed for redistribution or modification.
